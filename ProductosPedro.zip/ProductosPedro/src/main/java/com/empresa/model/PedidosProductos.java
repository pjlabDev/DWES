/**
 * 
 */
package com.empresa.model;

/**
 * @author estudiante
 *
 */
public class PedidosProductos {

	private int CodPedProd;
	private int pedido;
	private int producto;
	private int unidades;
	
	/**
	 * @param CodPedProd
	 * @param pedido
	 * @param producto
	 * @param unidades
	 */
	public PedidosProductos(int CodPedProd, int pedido, int producto, int unidades) {
		this.CodPedProd = CodPedProd;
		this.pedido = pedido;
		this.producto = producto;
		this.unidades = unidades;
	}

	public int getCodPedProd() {
		return CodPedProd;
	}

	public void setCodPedProd(int codPedProd) {
		CodPedProd = codPedProd;
	}

	public int getPedido() {
		return pedido;
	}

	public void setPedido(int pedido) {
		this.pedido = pedido;
	}

	public int getProducto() {
		return producto;
	}

	public void setProducto(int producto) {
		this.producto = producto;
	}

	public int getUnidades() {
		return unidades;
	}

	public void setUnidades(int unidades) {
		this.unidades = unidades;
	}
	
}
