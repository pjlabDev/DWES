/**
 * 
 */
package com.empresa.model;

/**
 * @author estudiante
 *
 */
public class Pedidos {
	
	private int CodPed;
	private String fecha;
	private int enviado;
	private int restaurante;
	
	/**
	 * @param CodPed
	 * @param fecha
	 * @param enviado
	 * @param restaurante
	 */
	public Pedidos(int CodPed, String fecha, int enviado, int restaurante) {
		this.CodPed = CodPed;
		this.fecha = fecha;
		this.enviado = enviado;
		this.restaurante = restaurante;
	}

	public int getCodPed() {
		return CodPed;
	}

	public void setCodPed(int codPed) {
		CodPed = codPed;
	}

	public String getFecha() {
		return fecha;
	}

	public void setFecha(String fecha) {
		this.fecha = fecha;
	}

	public int getEnviado() {
		return enviado;
	}

	public void setEnviado(int enviado) {
		this.enviado = enviado;
	}

	public int getRestaurante() {
		return restaurante;
	}

	public void setRestaurante(int restaurante) {
		this.restaurante = restaurante;
	}
	
}
