/**
 * 
 */
package com.empresa.model;

/**
 * @author estudiante
 *
 */
public class Categorias {

	private int CodCat;
	private String nombre;
	private String descripcion;
	
	/**
	 * @param CodCat
	 * @param nombre
	 * @param descripcion
	 */
	public Categorias(int CodCat, String nombre, String descripcion) {
		this.CodCat = CodCat;
		this.nombre = nombre;
		this.descripcion = descripcion;
	}

	public int getCodCat() {
		return CodCat;
	}

	public void setCodCat(int codCat) {
		CodCat = codCat;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}
	
}
