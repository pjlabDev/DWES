/**
 * 
 */
package com.empresa.model;

/**
 * @author estudiante
 *
 */
public class Restaurantes {
	
	private int CodRes;
	private String correo;
	private String clave;
	private String pais;
	private int cp;
	private String ciudad;
	private String direccion;
	
	/**
	 * @param CodRes
	 * @param correo
	 * @param clave
	 * @param pais
	 * @param cp
	 * @param ciudad
	 * @param direccion 
	 */
	public Restaurantes(int CodRes, String correo, String clave, String pais, int cp, String ciudad, String direccion) {
		this.CodRes = CodRes;
		this.correo = correo;
		this.clave = clave;
		this.pais = pais;
		this.cp = cp;
		this.ciudad = ciudad;
		this.direccion = direccion;
	}

	public int getCodRes() {
		return CodRes;
	}

	public void setCodRes(int codRes) {
		CodRes = codRes;
	}

	public String getCorreo() {
		return correo;
	}

	public void setCorreo(String correo) {
		this.correo = correo;
	}

	public String getClave() {
		return clave;
	}

	public void setClave(String clave) {
		this.clave = clave;
	}

	public String getPais() {
		return pais;
	}

	public void setPais(String pais) {
		this.pais = pais;
	}

	public int getCp() {
		return cp;
	}

	public void setCp(int cp) {
		this.cp = cp;
	}

	public String getCiudad() {
		return ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public String getDireccion() {
		return direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	
}
