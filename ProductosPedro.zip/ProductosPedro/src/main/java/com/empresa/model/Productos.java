/**
 * 
 */
package com.empresa.model;

/**
 * @author estudiante
 *
 */
public class Productos {
	
	private int CodProd;
	private String nombre;
	private String descripcion;
	private double peso;
	private int stock;
	private int categoria;
	
	/**
	 * @param CodProd
	 * @param nombre
	 * @param descripcion
	 * @param peso
	 * @param stock
	 * @param categoria
	 */
	public Productos(int CodProd, String nombre, String descripcion, double peso, int stock, int categoria) {
		this.CodProd = CodProd;
		this.nombre = nombre;
		this.descripcion = descripcion;
		this.peso = peso;
		this.stock = stock;
		this.categoria = categoria;
	}

	public int getCodProd() {
		return CodProd;
	}

	public void setCodProd(int codProd) {
		CodProd = codProd;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public int getCategoria() {
		return categoria;
	}

	public void setCategoria(int categoria) {
		this.categoria = categoria;
	}

}
