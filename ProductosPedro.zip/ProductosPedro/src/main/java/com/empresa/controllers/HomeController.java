/**
 * 
 */
package com.empresa.controllers;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.TreeSet;

import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * 
 * @author usuario
 * 
 */
@Controller
@EnableAutoConfiguration
public class HomeController {

	TreeSet<String> listaDirectores = new TreeSet<>();

//	Método que lleva a la página principal, dejando vacia la lista de directores consultados.
	@RequestMapping("/")
	public String irPrincipal() {
		return "principal";
	}
	
	@RequestMapping("/loginPage")
	public String irLoginPage() {
		return "login";
	}

}