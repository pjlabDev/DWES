package com.empresa.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.empresa.controllers.HomeController;

@SpringBootApplication
public class ProductosPedroApplication {

	public static void main(String[] args) {
		SpringApplication.run(HomeController.class, args);
	}

}
